$(document).ready(function() {
	// Code client
});


